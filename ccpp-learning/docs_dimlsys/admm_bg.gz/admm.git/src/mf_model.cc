#include "./mf_model.h"

namespace admm {
DMLC_REGISTER_PARAMETER(MFModelParam);

MFModel::MFModel() {
}

MFModel::~MFModel() {
}

KWArgs MFModel::Init(const KWArgs& kwargs) {
  auto remained = param_.InitAllowUnknown(kwargs);
  store_.resize(param_.k * param_.k * param_.field_num, 0.1);
  return remained;
}

void MFModel::Update(ps::SArray<real_t>& Vif,
                     ps::SArray<real_t>& Theta, 
                     ps::SArray<real_t>& Beta) {
  auto grad_ = [&](feaid_t i, feaid_t f, feaid_t k){
    real_t result = Vif[k0 + k] + Beta[k0 + k];
    for (auto j = 0u; j < param_.k; ++j) {
      reault -= store_[k1 + j] *
                Theta[k0 + j];
    }
    return result;
  };

  for (auto i = 0u; i < param_.dimensions; ++i)
  for (auto f = 0u; f < param_.field_num; ++f) {
    feaid_t k0 = param_.field_num * param_.k * i + param_.k * f;
    for (auto k = 0u; k <param_.k; ++k) {
      feaid_t k1 = param_.k * param_.k * f + param_.k * k;

      real_t grad = grad_(i, f, k);
      for (auto d = 0u; d < param_.k; ++d) {
        Theta[k0 + d] += param_.lr_t * grad * store_[k1 + d];
      }

      grad = grad_(i, f, k);
      for (auto d = 0u; d < param_.k; ++d) {
        store_[k1 + d] += param_.lr_a * grad * Theta[k0 + d];
      }
    }
  }
}

} // namespace admm
