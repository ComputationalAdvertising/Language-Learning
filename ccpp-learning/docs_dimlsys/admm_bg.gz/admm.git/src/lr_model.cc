#include "./lr_model.h"
#include "./metrics.h"

namespace admm{
DMLC_REGISTER_PARAMETER(LRModelParam);

LRModel::LRModel() {
}

LRModel::~LRModel() {
}

KWArgs LRModel::Init(const KWArgs& kwargs) {
  auto remained = param_.InitAllowUnknown(kwargs);
  store_.resize(param_.dim*3, 0);
  return remained;
}

real_t LRModel::Predict(const Row& row) {
  return row.SDot(store_.data(), param_.dim);
}

void LRModel::Update(const Row& row, real_t pred) {
#pragma omp parallel for num_threads(DEFAULT_NTHREADS)
  for (auto i = 0u; i < row.length; ++i) {
    auto idx = row.get_index(i);
    auto val = row.get_value(i);
    auto& wti = store_[idx];
    auto& zi = store_[param_.dim + idx];
    auto& ni = store_[param_.dim*2 + idx];
    auto partial_pred = Predict(row);
    // update metrics
    if (metrics_) metrics_->Accumulate(partial_pred+pred, row.label);
    auto gi = gradient_(partial_pred+pred, row.label, idx, val);
    auto sigmai = (std::sqrt(ni + gi*gi) - std::sqrt(ni))/param_.alpha;
    // update zi and ni
    zi += gi - sigmai*wti;
    ni += gi*gi;
    if (use_ftrl_) {
      if (abs(zi) > param_.l1) {
        wti = param_.l1 * (zi>0.0?1.0:-1.0) - zi;
        wti /= (param_.beta + sqrt(ni))/param_.alpha + param_.l2;
      } else {
        wti = 0.0;
      }
    } else {
      wti -= param_.alpha*gi/(param_.beta+sqrt(ni));
    }
  }
}

void LRModel::Save(dmlc::Stream* fo) {
}

void LRModel::Load(dmlc::Stream* fi) {
}
}  // namespace admm
