#include <vector>
#include <rabit/rabit.h>
#include "framework.h"

int main(int argc, char* argv[]) {

  rabit::Init(argc, argv);

  int array[4] = {1, rabit::GetRank(), -1, 8};

  auto before_allreduce = [&]() {
    rabit::TrackerPrintf("Before allreduce at rank(%d)", rabit::GetRank());
  };
  auto at_allreduce = [&]() {
    rabit::TrackerPrintf("Allreducing at rank (%d)", rabit::GetRank());
    rabit::Allreduce<rabit::op::Sum>(&(array[0]), 4);
    if (rabit::GetRank() == 0) {
      rabit::TrackerPrintf("Allreduced result: (%d, %d, %d, %d)", array[0], array[1], array[2], array[3]);
    }
  };
  auto after_allreduce = [&]() {
    rabit::TrackerPrintf("After allreduce at rank(%d)", rabit::GetRank());
  };

  admm::Framework framework;
  framework.SetBeforeAllreduceCallback(before_allreduce);
  framework.SetAtAllreduceCallback(at_allreduce);
  framework.SetAfterAllreduceCallback(after_allreduce);
 
  framework.RunIterations(3);

  rabit::Finalize();
  return 0;
}

