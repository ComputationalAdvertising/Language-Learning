#include "./ffm_model.h"

namespace admm {
DMLC_REGISTER_PARAMETER(FFMModelParam);

FFMModel::FFMModel() {
}

FFMModel::~FFMModel() {
}

KWArgs FFMModel::Init(const KWArgs& kwargs) {
  auto remained = param_.InitAllowUnknown(kwargs);
  // Vi,f + w stored
  store_.resize(param_.dimensions * param_.field_num * param_.k * 2 + 
                param_.dimensions, 0.1);
  return remained;
}

inline bool FFMModel::SameField(feaid_t lhs, feaid_t rhs) {
  return (lhs^rhs)%(1 << param_.feagrp_nbits) == 0;
}

real_t FFMModel::Predict(const Row& row) {
  auto linear = row.SDot(store_.data(), param_.dimensions);
  real_t quad = 0;
  for (auto i = 0u; i < row.length - 1; ++i) {
    feaid_t fj = DecodeFeaGrpID(row.index[i], param_.feagrp_nbits);
    int Vi = param_.field_num * param_.k * 
                   (row.index[i] >> param_.feagrp_nbits) +
                   fj * param_.k;

    for (auto j = i+1; j < row.length; ++j) {
      feaid_t fi = DecodeFeaGrpID(row.index[j], param_.feagrp_nbits); 
      if (fj == fi) continue;

      int Vj = param_.field_num * param_.k * 
                     (row.index[j] >> param_.feagrp_nbits) +
                     fi * param_.k;

      for (size_t k = 0; k < param_.k; ++k) {
        quad += store_[Vi + k] * store_[Vj + k];
      }
    }
  }
  return linear + quad;
}

void FFMModel::Update(const Row& row, real_t pred, 
                      ps::SArray<real_t>& w_reg = ps::SArray(),
                      ps::SArray<real_t>& V_reg = ps::SArray()) {
  auto partial_pred = Predict(row); 
  auto p = 1.0/(1.0 + std::exp(- std::min(10.0f, std::max(-10.0f, partial_pred + pred))));
  if (row.label > 0) p = p - 1;

  // update w = ....
  auto w0 = param_.dimensions * param_.field_num * param_.k * 2;
  for (auto i = 0u; i < row.length; ++i) {
    feaid_t wi = row.index[i] >> param_.feagrp_nbits; 
    if (!row.value)
      store_[w0 + wi] -= param_.lr * (p + param_.w_l2 * store_[w0 + wi] + param_.w_l2 * (!w_reg.empty()? w_reg[wi] : 0)); 
    else
      store_[w0 + wi] -= param_.lr * (p * row.value[i] +
                         param_.w_l2 * store_[w0 + wi] + 
                         param_.w_l2 * (!w_reg.empty()? w_reg[wi] : 0));
  }

  // update V = ....
  auto V0 = param_.dimensions * param_.field_num * param_.k;
  for (auto i = 0u; i < row.length; ++i) {
    real_t yi = row.value? row.value[i] : 1;
    feaid_t fj = DecodeFeaGrpID(row.index[i], param_.feagrp_nbits);
    int Vi = param_.field_num * param_.k * 
             (row.index[i] >> param_.feagrp_nbits) +
             fj * param_.k;

    for (auto j = i+1; j < row.length; ++j) {
      real_t yj = row.value? row.value[j] : 1;
      feaid_t fi = DecodeFeaGrpID(row.index[j], param_.feagrp_nbits);
      int Vj = param_.field_num * param_.k *
              (row.index[j] >> param_.feagrp_nbits) +
              fi * param_.k;
      
      if (fi == fj) continue;

      for (auto k = 0u; k < param_.k; ++k) {
        real_t gradi = yi * yj * p * store_[Vi + k] + param_.V_l2 * (store_[Vi + k] + (!V_reg.empty()? V_reg[k] : 0));
        real_t gradj = yi * yj * p * store_[Vj + k] + param_.V_l2 * (store_[Vj + k] + (!V_reg.empty()? V_reg[k] : 0));

        store_[V0 + Vi + k] += gradi * gradi;
        store_[V0 + Vj + k] += gradj * gradj;

        store_[Vi + k] -= param_.lr * gradi / sqrt(store_[V0 + Vi + k]);
        store_[Vj + k] -= param_.lr * gradj / sqrt(store_[V0 + Vj + k]);
      }
    }
  }
}

} // namespace admm
