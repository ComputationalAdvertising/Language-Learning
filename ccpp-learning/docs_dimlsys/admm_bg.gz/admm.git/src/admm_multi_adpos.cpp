#include "rabit/rabit.h"
#include "dmlc/parameter.h"
#include "./arg_parser.h"
#include "./multi_adpos_learner.h"

int main(int argc, char* argv[]) {
  if (argc < 2) {
    LOG(ERROR) << "usage: " << argv[0] << " key1=val1 key2=val2 ...";
    return 0;
  }
  admm::ArgParser parser;
  for (int i = 1; i < argc; ++i) parser.AddArg(argv[i]);

  rabit::Init(argc, argv);
  admm::MultiAdposLearner learner;
  learner.Init(parser.GetKWArgs());
  learner.Run();
  return 0;
}

