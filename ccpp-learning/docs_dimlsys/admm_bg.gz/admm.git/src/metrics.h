#ifndef _ADMM_METRICS_H_
#define _ADMM_METRICS_H_
#include <memory>
#include "./base.h"

namespace admm {

class Metrics {
 public:
  Metrics();
  virtual ~Metrics();
  void Reset();
  void Accumulate(real_t pred, real_t label);
  real_t LocalAUC();
  real_t GlobalAUC();
  real_t LocalLogLoss();
  real_t GlobalLogLoss();
  inline uint32_t* CountData() {return split_count_.get();}
  inline real_t* LossData() {return &loss_data_[0];}
 protected:
  const size_t MAX_SPLIT = 10000;
  /** \brief splitted samples count.
   * [0, MAX_SPLIT) positive count,
   * [MAX_SPLIT, 2*MAX_SPLIT) negative count,
   * [2*MAX_SPLIT] num samples,
   * [2*MAX_SPLIT+1] num positive samples.
   */
  std::unique_ptr<uint32_t[]> split_count_;
  /** \brief accumulated loss & sample count.
   * Contains {sum of loss, num of samples}.
   */
  real_t loss_data_[2]; 
};

}  // namespace admm
#endif  // _ADMM_METRICS_H_
