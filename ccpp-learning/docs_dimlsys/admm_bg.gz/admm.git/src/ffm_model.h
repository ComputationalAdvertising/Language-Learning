#ifndef _ADMM_FFM_MODEL_H_
#define _ADMM_FFM_MODEL_H_
#include "./model.h"
#include "./sarray.h"
#include <map>

namespace admm {

class FFMModelParam : public dmlc::Parameter<FFMModelParam> {
 public:
  /*!  \brief regular coeffiecients
   */
   real_t w_l2;
   real_t V_l2;
   real_t lr;
   int feagrp_nbits;
   int field_num;
   std::size_t k;
   std::size_t dimensions;

   DMLC_DECLARE_PARAMETER(FFMModelParam) {
     DMLC_DECLARE_FIELD(w_l2).set_default(0.1);
     DMLC_DECLARE_FIELD(V_l2).set_default(1.0);
     DMLC_DECLARE_FIELD(lr).set_default(0.3);
     DMLC_DECLARE_FIELD(feagrp_nbits).set_default(2);
     DMLC_DECLARE_FIELD(field_num).set_default(3);
     DMLC_DECALRE_FIELD(k).set_default(5);
     DMLC_DECLARE_FIELD(dimensions);
   }
};

class FFMModel : Model {
 public:
  FFMModel();
  virtual ~FFMModel();

  KWArgs Init(const KWArgs& kwargs) override;

  real_t Predict(const dmlc::Row& row) override;

  inline void SetMetrics(const std::shared_ptr<Metrics>& metrics) override {
    metrics_ = metrics;
  }
  inline real_t* Data() override {return stored_.data();}
  void Update(const dmlc::Row& row, real_t pred, 
              ps::SArray<real_t>& offset_w,
              ps::SArray<real_t>& offset_V);

  inline void SetIntercept(
      const std::function<real_t(feaid_t)>& g) {
    intercept_w_ = g;
  }
  inline void SetIntercept(
      const std::function<real_t(int, int, feaid_t)>& g) {
    intercept_v_ = g;    
  }
  inline bool SameField(feaid_t lhs, feaid_t rhs);
  void Save(dmlc::Stream* fo) override;
  void Load(dmlc::Stream* fi) override;
  
 protected:
  FFMModelParam param_;
  ps::SArray<real_t> store_;
  std::shared_ptr<Metrics> metrics_;
  std::function<real_t(feaid_t)> intercept_w_;
  std::function<real_t(int, int, feaid_t)> intercept_v_;
};
}  // namespace admm
#endif  // _ADMM_FFM_MODEL_H_
