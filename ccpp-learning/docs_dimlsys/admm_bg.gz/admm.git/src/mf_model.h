#ifndef _ADMM_MF_MODEL_H_
#define _ADMM_MF_MODEL_H_
#include "./model.h"
#include "./sarray.h"
#include <map>

namespace admm {

class MFModelParam : public dmlc::Parameter<MFModelParam> {
 public:
  /*! \brief ffm latents global model  
   */
   feaid_t dimensions;
   feaid_t k;
   feaid_t field_num;
   int feagrp_nbits;
   real_t lr_t;
   real_t lr_a;
   real_t eta;

   DMLC_DECLARE_PARAMETER(MFModelParam) {
     DMLC_DECLARE_FIELD(k).set_default(5);
     DMLC_DECLARE_FIELD(field_num).set_default(3);
     DMLC_DECLARE_FIELD(feagrp_nbits).set_default(2);
     DMLC_DECLARE_FIELD(lr_t).set_default(0.3);
     DMLC_DECLARE_FIELD(lr_a).set_default(0.3);
     DMLC_DECLARE_FIELD(eta);
   }
};

class MFModel :  Model {
 public:
  MFModel();
  virtual ~MFModel();

  KWArgs Init(const KWArgs& kwargs) override;

  void Update(ps::SArray<real_t>& Vif, ps::SArray<real_t>& Theta, ps::SArray<real_t>& Beta); 

  void Save(dmlc::Stream* fo) override;
  void Load(dmlc::Stream* fi) override;

 protected:
  MFModelParam param_;
  ps::SArray<real_t> store_;
  std::shared_ptr<Metrics> metrics_;
};

} // namespace admm

#endif // _ADMM_MF_MODEL_H_
