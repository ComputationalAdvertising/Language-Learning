#ifndef _ADMM_BASE_H_
#define _ADMM_BASE_H_

#include <vector>
#include <string>
#include <functional>
#include "dmlc/logging.h"
#include "dmlc/data.h"

#define DEFAULT_NTHREADS 2

namespace admm {

typedef std::vector<std::pair<std::string, std::string>> KWArgs;

typedef float real_t;
typedef uint32_t feaid_t;
typedef dmlc::Row<feaid_t> Row;
typedef dmlc::RowBlockIter<feaid_t> DataStore;
typedef std::function<real_t(real_t pred, real_t label, feaid_t idx, real_t value)> Gradient;
typedef std::function<real_t(real_t* w, feaid_t idx, real_t gradient)> Updater;

/**
 * \brief generate a new feature index containing the feature group id
 *
 * @param x the feature index
 * @param gid feature group id
 * @param nbits number of bits used to encode gid
 * @return the new feature index
 */
inline feaid_t EncodeFeaGrpID(feaid_t x, int gid, int nbits) {
  CHECK_GE(gid, 0); CHECK_LT(gid, 1 << nbits);
  return (x << nbits) | gid;
}
/**
 * \brief get the feature group id from a feature index
 *
 * @param x the feature index
 * @param nbits number of bits used to encode gid
 * @return the feature group id
 */
inline feaid_t DecodeFeaGrpID(feaid_t x, int nbits) {
  return x % (1 << nbits);
}

}  // namespace admm
#endif  // _ADMM_BASE_H_
