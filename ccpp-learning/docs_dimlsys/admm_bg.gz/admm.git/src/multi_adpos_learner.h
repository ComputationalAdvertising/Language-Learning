#ifndef _ADMM_MULTI_ADPOS_LEARNER_H_
#define _ADMM_MULTI_ADPOS_LEARNER_H_
#include <memory>
#include "dmlc/parameter.h"
#include "dmlc/data.h"
#include "./base.h"
#include "./metrics.h"
#include "sarray.h"

namespace dmlc {
class Stream;
}

namespace admm {
class Metrics;
class Model;
class MultiAdposLearnerParam : public dmlc::Parameter<MultiAdposLearnerParam> {
 public:
  /** \brief model type, either lr or ffm. */
  std::string model;
  /** \brief maximal num ofdata passes, default is 10. */
  int num_iterations;
  /** \brief num of passes to iterate over the data at each iteration. */
  int passes;
  /** \brief augmented Lagrangian factor, currently as fixed. default 0.1 */
  real_t rho;
  /** \brief global model update l1 reg factor. */
  real_t lambda_w1;
  /** \brief global model update l2 reg factor. */
  real_t lambda_w2;
  /** \brief The input data, either a filename or a directory. */
  std::string data_in;
  /** \brief The optional validation dataset, either a filename or a directory */
  std::string data_val;
  /** \brief the data format. default is libsvm */
  std::string model_out;
  /** \brief the model input for warm start */
  std::string model_in;
  /** \brief the dimension of the data/model */
  std::size_t dimensions;
  /** \brief type of loss, defaut is fm*/
  DMLC_DECLARE_PARAMETER(MultiAdposLearnerParam) {
    DMLC_DECLARE_FIELD(model).set_default("lr");
    DMLC_DECLARE_FIELD(num_iterations).set_default(10);
    DMLC_DECLARE_FIELD(passes).set_default(1);
    DMLC_DECLARE_FIELD(rho).set_default(0.1);
    DMLC_DECLARE_FIELD(lambda_w1).set_default(0.1);
    DMLC_DECLARE_FIELD(lambda_w2).set_default(1.0);
    DMLC_DECLARE_FIELD(data_in);
    DMLC_DECLARE_FIELD(data_val).set_default("");
    DMLC_DECLARE_FIELD(model_out).set_default("");
    DMLC_DECLARE_FIELD(model_in).set_default("");
    DMLC_DECLARE_FIELD(dimensions);
  }
};

class MultiAdposLearner {
 public:
  MultiAdposLearner() {}
  virtual ~MultiAdposLearner() {}

  KWArgs Init(const KWArgs& args);
  void Run();

  void SaveModel(bool with_aux, dmlc::Stream* fo);
  void LoadModel(dmlc::Stream* fi, bool* with_aux);

 protected:
  void UpdateLocalModel();
  void UpdateGlobalModel();
  void UpdateDual();

  /** Iterate over training data and update model m1.
   * m2 is the other one of the two combined model,
   * local vs global or global vs local.
   */
  void IterateTrain(std::shared_ptr<Model> m1,
      std::shared_ptr<Model> m2);
 
  /** Iterate over testing data and get the prediction
   * evaluations.
   */
  void IterateTest(std::shared_ptr<Model> m1,
      std::shared_ptr<Model> m2);

  MultiAdposLearnerParam param_;
  std::shared_ptr<Model> local_model_;
  std::shared_ptr<Model> global_model_;
  ps::SArray<real_t> agg_global_model_;
  ps::SArray<real_t> dual_;
  std::unique_ptr<DataStore> training_data_;
  std::unique_ptr<DataStore> testing_data_;
  std::shared_ptr<Metrics> training_metrics_;
  std::shared_ptr<Metrics> testing_metrics_;
};

}  // namespace admm
#endif  // _ADMM_MULTI_ADPOS_LEARNER_H_
