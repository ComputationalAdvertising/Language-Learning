#ifndef _ADMM_LR_MODEL_H_
#define _ADMM_LR_MODEL_H_
#include "./model.h"
#include "./sarray.h"

namespace admm {

class LRModelParam : public dmlc::Parameter<LRModelParam> {
 public:
  /** \brief Per-coordinate learning rate alpha.
   */
  real_t alpha;
  real_t beta;
  real_t l1;
  real_t l2;
  feaid_t dim;

  DMLC_DECLARE_PARAMETER(LRModelParam) {
    DMLC_DECLARE_FIELD(alpha).set_default(0.01);
    DMLC_DECLARE_FIELD(beta).set_default(0.1);
    DMLC_DECLARE_FIELD(l1).set_default(1.0);
    DMLC_DECLARE_FIELD(l2).set_default(10.0);
    DMLC_DECLARE_FIELD(dim);
  }
};

/** \brief The logistic regression model.
 * We use an FTRL solver to estimate the parameters online.
 */
class LRModel : public Model {
 public:
  LRModel();
  virtual ~LRModel();
 
  KWArgs Init(const KWArgs& kwargs) override;

  real_t Predict(const Row& row) override;
  
  /** \brief Online updating of the model params.
   * For FTRL, the pred should be omitted.
   * For Multi-Adpos algo, the pred is other model's
   * contribution on the raw prediction.
   */
  void Update(const Row& row, real_t pred) override;

  /** \brief Set gradient calculation function.
   */
  inline void SetGradient(
      const Gradient& g) override {
    gradient_ = g;
  }
  inline void SetUpdater(bool uf) {use_ftrl_ = uf;}

  inline void SetMetrics(const std::shared_ptr<Metrics>& metrics) override {
    metrics_ = metrics;
  }
  inline real_t* Data() override {return store_.data();}
  void Save(dmlc::Stream* fo) override;
  void Load(dmlc::Stream* fi) override;

 protected:
  LRModelParam param_;
  ps::SArray<real_t> store_;
  std::shared_ptr<Metrics> metrics_;
  Gradient gradient_;
  bool use_ftrl_;
};
}  // namespace admm
#endif  // _ADMM_LR_MODEL_H_
