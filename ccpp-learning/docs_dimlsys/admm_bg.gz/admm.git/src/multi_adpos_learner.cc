#include "./multi_adpos_learner.h"
#include <sstream>
#include "dmlc/io.h"
#include "rabit/rabit.h"
#include "./base.h"
#include "./model.h"
#include "./lr_model.h"

namespace admm {
DMLC_REGISTER_PARAMETER(MultiAdposLearnerParam);

KWArgs MultiAdposLearner::Init(const KWArgs& args) {
  auto remained = param_.InitAllowUnknown(args);
  if (param_.model == "lr") {
    local_model_.reset(new LRModel);
    global_model_.reset(new LRModel);
  } else if (param_.model == "ffm") {
    CHECK(false);
  } else {
    CHECK(false);
  }
  local_model_->Init(args);
  global_model_->Init(args);
  local_model_->SetGradient([&](
        real_t pred, real_t label, feaid_t idx, real_t x = 1.0) {
      auto p = std::max(-10.0f, std::min(10.0f, pred));
      return -label*x / (1.0 + std::exp(label*p));
      });
  local_model_->SetUpdater(true);
  global_model_->SetGradient([&](
        real_t pred, real_t label, feaid_t idx, real_t x = 1.0) {
      auto p = std::max(-10.0f, std::min(10.0f, pred));
      auto gll = -label*x / (1.0 + std::exp(label*p));
      gll += param_.rho * (global_model_->Data()[idx] - agg_global_model_[idx]) + dual_[idx];
      return gll;
      });
  global_model_->SetUpdater(false);
  dual_.resize(param_.dimensions, 0);
  agg_global_model_.resize(param_.dimensions, 0);

  std::istringstream iss(param_.data_in);
  std::string temp_item;
  std::vector<std::string> paths;
  while (std::getline(iss, temp_item, ',')) {
    paths.push_back(temp_item);
  }
  // XXX: num of inputs should be queal to num of workers
  CHECK_EQ(rabit::GetWorldSize(), static_cast<int>(paths.size()));
  param_.data_in = paths[rabit::GetRank()];
  auto data = DataStore::Create(param_.data_in.c_str(), 0, 1, "libsvm");
  CHECK_NOTNULL(data);
  training_data_.reset(data);
  training_metrics_.reset(new Metrics);
  local_model_->SetMetrics(training_metrics_);
  global_model_->SetMetrics(training_metrics_);
  if (param_.data_val != "") {
    std::istringstream iss(param_.data_val);
    paths.clear();
    while (std::getline(iss, temp_item, ',')) {
      paths.push_back(temp_item);
    }
    CHECK_EQ(rabit::GetWorldSize(), static_cast<int>(paths.size()));
    param_.data_val = paths[rabit::GetRank()];
    data = DataStore::Create(param_.data_val.c_str(), 0, 1, "libsvm");
    CHECK_NOTNULL(data);
    testing_data_.reset(data);
    testing_metrics_.reset(new Metrics);
  }
  // TODO model_in ....
  {  // model_out here
    paths.clear();
    std::istringstream iss(param_.model_out);
    while (std::getline(iss, temp_item, ',')) {
      paths.push_back(temp_item);
    }
    CHECK_EQ(rabit::GetWorldSize(), static_cast<int>(paths.size()));
    param_.model_out = paths[rabit::GetRank()];
  }
  return remained;
}

void MultiAdposLearner::Run() {
  for (auto i = 0; i < param_.num_iterations; ++i) {
    if (rabit::GetRank() == 0) rabit::TrackerPrintf("Iteration %d ...", i);
    UpdateGlobalModel();
    // UpdateLocalModel();
    UpdateDual();
  }
}

void MultiAdposLearner::SaveModel(bool with_aux, dmlc::Stream* fo) {
  // TODO
  for (auto i = 0u; i < param_.dimensions; ++i) {
  }
}

void MultiAdposLearner::LoadModel(dmlc::Stream* fi, bool* with_aux) {
  // TODO 
}

//////////////////////////////////////////

void MultiAdposLearner::UpdateLocalModel() {
  IterateTrain(local_model_, global_model_);
  auto logloss = training_metrics_->GlobalLogLoss();
  auto auc = training_metrics_->GlobalAUC();
  if (rabit::GetRank() == 0) {
    rabit::TrackerPrintf("Local Model. Training log-loss: %f, AUC: %f",
        logloss, auc);
  }
  IterateTest(local_model_, global_model_);
  if (testing_metrics_) {
    logloss = testing_metrics_->GlobalLogLoss();
    auc = testing_metrics_->GlobalAUC();
    if (rabit::GetRank() == 0) {
      rabit::TrackerPrintf("Local Model. Testing log-loss: %f, AUC: %f",
          logloss, auc);
    }
  }
}

void MultiAdposLearner::UpdateGlobalModel() {
  IterateTrain(global_model_, local_model_);
  auto logloss = training_metrics_->GlobalLogLoss();
  auto auc = training_metrics_->GlobalAUC();
  if (rabit::GetRank() == 0) {
    rabit::TrackerPrintf("Global Model. Training log-loss: %f, AUC: %f",
        logloss, auc);
  }
#pragma omp parallel for num_threads(DEFAULT_NTHREADS)
  for (auto i = 0u; i < param_.dimensions; ++i) {
    agg_global_model_[i] = global_model_->Data()[i] + dual_[i]/(param_.rho+1e-8);
  }
  rabit::Allreduce<rabit::op::Sum>(agg_global_model_.data(), param_.dimensions);
  if (rabit::GetRank() == 1) {
    auto scale = param_.rho * rabit::GetWorldSize() + param_.lambda_w2 + 1e-8;
#pragma omp parallel for num_threads(DEFAULT_NTHREADS)
    for (auto i = 0u; i < param_.dimensions; ++i) {
      auto& wt = agg_global_model_[i];
      if (wt > param_.lambda_w1) {
        wt = (wt - param_.lambda_w1) / scale;
      } else if (wt < -param_.lambda_w1) {
        wt = (wt + param_.lambda_w1) / scale;
      } else {
        wt = 0;
      }
    }
  }
  rabit::Broadcast(agg_global_model_.data(), sizeof(real_t)*param_.dimensions, 1);
  IterateTest(global_model_, local_model_);
  if (testing_metrics_) {
    logloss = testing_metrics_->GlobalLogLoss();
    auc = testing_metrics_->GlobalAUC();
    if (rabit::GetRank() == 0) {
      rabit::TrackerPrintf("Global model. Testing log-loss: %f, AUC: %f", logloss, auc);
    }
  }
}

void MultiAdposLearner::UpdateDual() {
  // dual ascent
  // // local updated global model - broadcasted global model
  #pragma omp parallel for num_threads(DEFAULT_NTHREADS)
  for (auto i = 0u; i < param_.dimensions; ++i) {
    dual_[i] += param_.rho * (global_model_->Data()[i] - agg_global_model_[i]);
  }
}

void MultiAdposLearner::IterateTrain(
    std::shared_ptr<Model> m1, std::shared_ptr<Model> m2) {
  training_metrics_->Reset();
  for (int pass = 0; pass < param_.passes; ++pass) {
    training_data_->BeforeFirst();
    while (training_data_->Next()) {
      auto block = training_data_->Value();
      for (auto i = 0u; i < block.size; ++i) {
        const auto& row = block[i];
        auto other_pred = m2->Predict(row);
        m1->Update(row, other_pred);
      }
    }
  }
}

void MultiAdposLearner::IterateTest(
    std::shared_ptr<Model> m1, std::shared_ptr<Model> m2) {
  if (testing_data_) {
    testing_metrics_->Reset();
    testing_data_->BeforeFirst();
    while (testing_data_->Next()) {
      auto block = testing_data_->Value();
      for (auto i = 0u; i < block.size; ++i) {
        testing_metrics_->Accumulate(
            m1->Predict(block[i]) + m2->Predict(block[i]),
            block[i].label);
      }
    }
  }
}
}  // namespace admm
