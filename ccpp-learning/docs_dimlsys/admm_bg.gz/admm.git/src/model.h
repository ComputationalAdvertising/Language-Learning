#ifndef _ADMM_MODEL_H_
#define _ADMM_MODEL_H_
#include <memory>
#include "./base.h"

namespace dmlc {
template<typename T>class Row;
}
namespace admm {
class Metrics;
class Model {
 public:
  Model() {};
  virtual ~Model() {};
  virtual KWArgs Init(const KWArgs& kwargs) = 0;
  virtual real_t Predict(const Row& row) = 0;
  virtual void Update(const Row& row, real_t pred) = 0;
  virtual real_t* Data() = 0;
  virtual void SetGradient(const std::function<
      real_t(real_t, real_t, feaid_t, real_t)>&) = 0;
  // TODO(baigang) elegant solution...
  virtual void SetUpdater(bool use_ftrl) = 0;
  virtual void SetMetrics(const std::shared_ptr<Metrics>& metrics) = 0;
  virtual void Save(dmlc::Stream* fo) = 0;
  virtual void Load(dmlc::Stream* fi) = 0;
 protected:
};
}  // namespace admm
#endif  // _ADMM_MODEL_H_
