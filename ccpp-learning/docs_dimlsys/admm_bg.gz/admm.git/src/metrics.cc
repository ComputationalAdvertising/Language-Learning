#include "./metrics.h"
#include <cstring>  // for memset
#include "rabit/rabit.h"

namespace admm {

Metrics::Metrics() {
  split_count_.reset(new uint32_t[MAX_SPLIT<<1]);
}

Metrics::~Metrics() {
}

void Metrics::Reset() {
  memset(loss_data_, 0, 2*sizeof(real_t));
  memset(split_count_.get(), 0, (MAX_SPLIT<<1)*sizeof(uint32_t));
}

void Metrics::Accumulate(real_t pred, real_t label) {
  auto pre_val = std::min(1.0f, std::max(0.0f, 1.0f/(1.0f+std::exp(-pred))));
  uint32_t index = static_cast<uint32_t>(pre_val*MAX_SPLIT);
  if (label > 0.0f) {
    ++ split_count_[index];
  } else {
    ++ split_count_[MAX_SPLIT+index];
  }
  // not threading-safe
  auto margin = std::min(10.0f, std::max(-10.0f, pred*label));
  loss_data_[0] += std::log(1.0+std::exp(-margin));
  loss_data_[1] += 1.0;
}

real_t Metrics::LocalAUC() {
  auto auc = 0.0f;
  auto pre_tpr = 1.0;
  auto pre_fpr = 1.0;
  for (auto i = 0u; i < MAX_SPLIT; ++i) {
    auto tp = 0u;
    auto fn = 0u;
    auto fp = 0u;
    auto tn = 0u;
    auto tpr = 0.0;
    auto fpr = 0.0;
    for (auto j = 0u; j < i; ++j) {
      fn += split_count_[j];
      tn += split_count_[MAX_SPLIT+j];
    }
    for (auto j = i; j < MAX_SPLIT; ++j) {
      tp += split_count_[j];
      fp += split_count_[MAX_SPLIT+j];
    }
    if (tp + fn > 0) tpr = static_cast<double>(tp)/static_cast<double>(tp + fn);
    if (fp + tn > 0) fpr = static_cast<double>(fp)/static_cast<double>(fp + tn);
    auc += 0.5 * (pre_tpr+tpr) * (pre_fpr-fpr);
    pre_tpr = tpr;
    pre_fpr = fpr;
  }
  return static_cast<real_t>(auc);
}

real_t Metrics::GlobalAUC() {
  rabit::Allreduce<rabit::op::Sum>(split_count_.get(),
      MAX_SPLIT<<1);
  return LocalAUC();
}

real_t Metrics::LocalLogLoss() {
  //rabit::TrackerPrintf("Rank %d, sum-loss: %f, samples: %f",
  //    rabit::GetRank(), loss_data_[0], loss_data_[1]);
  if (loss_data_[1] > 0) {
    return loss_data_[0] / loss_data_[1];
  }
  return 0.0;
}

real_t Metrics::GlobalLogLoss() {
  rabit::Allreduce<rabit::op::Sum>(loss_data_, 2);
  return LocalLogLoss();
}

}  // namespace admm
