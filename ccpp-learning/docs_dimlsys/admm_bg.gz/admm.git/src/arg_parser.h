#ifndef _ADMM_ARG_PARSER_H_
#define _ADMM_ARG_PARSER_H_
#include <string>
#include <sstream>
#include "dmlc/io.h"
#include "dmlc/config.h"
#include "./base.h"
namespace admm {
class ArgParser {
 public:
  ArgParser() { }
  ~ArgParser() { }

  void AddArg(const char* argv) { data_.append(argv); data_.append(" "); }

  KWArgs GetKWArgs() {
    std::stringstream ss(data_);
    dmlc::Config* conf = new dmlc::Config(ss);

    for (auto it : *conf) {
      if (it.first == "argfile") {
        AddArgFile(it.second.c_str());
        delete conf;
        std::stringstream ss(data_);
        conf = new dmlc::Config(ss);
        break;
      }
    }
    KWArgs kwargs;
    for (auto it : *conf) {
      if (it.first == "argfile") continue;
      kwargs.push_back(it);
    }
    delete conf;
    return kwargs;
  }

 private:
  /**
   * \brief read all args in a file
   */
  void AddArgFile(const char* const filename) {
    dmlc::Stream *fs = dmlc::Stream::Create(filename, "r");
    CHECK(fs != nullptr) << "failed to open " << filename;
    char buf[1000];
    while (true) {
      size_t r = fs->Read(buf, 1000);
      data_.append(buf, r);
      if (!r) break;
    }
  }
  std::string data_;
};
}  // namespace admm
#endif  // _ADMM_ARG_PARSER_H_
