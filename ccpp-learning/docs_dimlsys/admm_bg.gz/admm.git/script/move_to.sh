#!/bin/bash

cp -r $1 /data2/data
